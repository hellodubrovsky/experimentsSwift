import UIKit

final class BlogPost: CustomDebugStringConvertible, CustomStringConvertible {
    var description: String {
        "Пост"
    }
    
    var debugDescription: String {
        "Пост с заголовком \(title) и содержанием \(body)"
    }
    
    let title: String
    let body: String
    
    init(title: String, body: String) {
        self.title = title
        self.body = body
    }
}

let blogPost = BlogPost(
    title: "Отладка",
    body: "Учимся отлаживать наше приложение"
)

print(blogPost)
debugPrint(blogPost)

struct Post {
    let title: String
    let body: String
}

let post = Post(
    title: "Отладка",
    body: "Учимся отлаживать наше приложение"
)

print(post)
debugPrint(post)

final class BlogPostViewController: UIViewController {
    let post: BlogPost
    
    init(post: BlogPost) {
        self.post = post
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

extension BlogPostViewController { // CustomDebugStringConvertible
    override var debugDescription: String {
        "\(self) содержит пост с заголовком \(post.title)"
    }
}

extension BlogPostViewController {
    override var description: String {
        "\(super.description) содержит пост с заголовком \(post.title)"
    }
}

let viewController = BlogPostViewController(post: blogPost)
print(viewController)
debugPrint(viewController)
