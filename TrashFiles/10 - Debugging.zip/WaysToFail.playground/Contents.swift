import UIKit

// assert

func printAgeAssert(_ age: Int) {
    assert(age >= 0, "Возраст не может быть отрицательным")
    
    print("Возраст: \(age)")
}

func printAgeAssertionFailure(_ age: Int) {
    guard age >= 0 else {
        assertionFailure("Возраст не может быть отрицательным")
        return
    }
    
    print("Возраст: \(age)")
}

// precondition

func printAgePrecondition(_ age: Int) {
    precondition(age >= 0, "Возраст не может быть отрицательным")
    
    print("Возраст: \(age)")
}

func printAgePreconditionFailure(_ age: Int) {
    guard age >= 0 else {
        preconditionFailure("Возраст не может быть отрицательным")
    }
    
    print("Возраст: \(age)")
}

printAgePreconditionFailure(-1)

// fatalError

func printAgeFatalError(_ age: Int) {
    guard age >= 0 else {
        fatalError("Возраст не может быть отрицательным")
    }
    
    print("Возраст: \(age)")
}

printAgeFatalError(-1)
