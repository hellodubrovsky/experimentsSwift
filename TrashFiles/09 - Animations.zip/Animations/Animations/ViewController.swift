import UIKit

class ViewController: UIViewController {
    
    let animatedView: UIView = UIView()
    var topContraint: NSLayoutConstraint?

    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = .systemYellow
        
        let recognizer = UITapGestureRecognizer()
        recognizer.addTarget(self, action: #selector(handlePressGesture(_:)))
        view.addGestureRecognizer(recognizer)
        
        animatedView.backgroundColor = .systemBlue
        animatedView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(animatedView)
        
        NSLayoutConstraint.activate([
            animatedView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 50.0),
            animatedView.heightAnchor.constraint(equalToConstant: 100.0),
            animatedView.widthAnchor.constraint(equalToConstant: 150.0)
        ])
        
        topContraint = animatedView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 50.0)
        topContraint?.isActive = true
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
//        animateBasic()
//        animateKeyFrames()
//        animatePropertyAnimator()
//        animateLayer()
    }

    @objc func handlePressGesture(_ gesture: UILongPressGestureRecognizer) {
        print("Did catch action")
    }
    
    fileprivate func animateBasic() {
        let start = animatedView.center
        
        UIView.animate(
            withDuration: 2.5,
            delay: 1.0,
            options: .curveEaseInOut) {
                self.animatedView.center = CGPoint(x: start.x, y: start.y + 700.0)
            } completion: { finished in
                print("Did finish animation")
            }
    }
    
    fileprivate func animateKeyFrames() {
        let start = animatedView.center
        
        UIView.animateKeyframes(
            withDuration: 5.0,
            delay: 0,
            options: .calculationModeCubic,
            animations: {
                UIView.addKeyframe(
                    withRelativeStartTime: 0.0,
                    relativeDuration: 0.25) {
                        self.animatedView.transform = CGAffineTransform(
                            scaleX: 2.0,
                            y: 2.0
                        )
                    }
                UIView.addKeyframe(
                    withRelativeStartTime: 0.25,
                    relativeDuration: 0.25) {
                        self.animatedView.center = CGPoint(
                            x: self.view.bounds.midX,
                            y: self.view.bounds.maxY
                        )
                    }
                UIView.addKeyframe(
                    withRelativeStartTime: 0.5,
                    relativeDuration: 0.25) {
                        self.animatedView.center = CGPoint(
                            x: self.view.bounds.width,
                            y: start.y
                        )
                    }
                UIView.addKeyframe(
                    withRelativeStartTime: 0.75,
                    relativeDuration: 0.25) {
                        self.animatedView.center = start
                        self.animatedView.transform = CGAffineTransform.identity
                    }
            },
            completion: { finished in
                
            })
    }
    
    fileprivate func animatePropertyAnimator() {
        let start = animatedView.center
        
        let animator = UIViewPropertyAnimator(
            duration: 5.0,
            curve: .linear
        )
        {
            self.animatedView.center = CGPoint(
                x: start.x,
                y: start.y + 700.0
            )
        }
        
        animator.startAnimation(afterDelay: 1.0)
    }
    
    fileprivate func animateLayer() {
        let start = animatedView.center
        
        CATransaction.begin()
        
        CATransaction.setCompletionBlock {
            self.topContraint?.constant += 700
            self.view.layoutIfNeeded()
        }
        
        let animation = CABasicAnimation(keyPath: #keyPath(CALayer.position))
        animation.toValue = CGPoint(x: start.x, y: start.y + 700.0)
        animation.duration = 5.0
        animation.autoreverses = false
        animation.isRemovedOnCompletion = true
        animatedView.layer.add(animation, forKey: #keyPath(CALayer.position))
        
        CATransaction.commit()
    }
}

