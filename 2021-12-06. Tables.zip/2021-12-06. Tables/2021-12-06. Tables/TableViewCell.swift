import UIKit

class TableViewCell: UITableViewCell {
    
    private lazy var label: UILabel = {
        let label = UILabel()
        
        label.translatesAutoresizingMaskIntoConstraints = false
        
        label.backgroundColor = .systemBlue
        label.textColor = .systemBackground
        
        return label
    }()
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: .default, reuseIdentifier: reuseIdentifier)
        
        accessoryType = .disclosureIndicator
        contentView.backgroundColor = .systemYellow
        
        contentView.addSubview(label)
        NSLayoutConstraint.activate([
            label.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 16.0),
            label.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -16.0),
            label.topAnchor.constraint(equalTo: contentView.topAnchor),
            label.bottomAnchor.constraint(equalTo: contentView.bottomAnchor)
        ])
        
        let constraint = label.heightAnchor.constraint(equalToConstant: 44.0)
        constraint.priority = UILayoutPriority.init(751)
        constraint.isActive = true
    }
    
    public func update(text: String) {
        label.text = text
    }
}
