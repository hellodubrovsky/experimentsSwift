import UIKit

class ViewController: UIViewController {
    
    fileprivate let animals: [String] = [
        "Horse",
        "Monkey",
        "Pig",
        "Cow",
        "Sheep",
        "Goat",
        "Cat",
        "Dog"
    ]
    
    fileprivate enum CellReuseIdentifiers: String {
        case animal
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        let tableView = UITableView()
        tableView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(tableView)
        
        NSLayoutConstraint.activate([
            tableView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor),
            tableView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor),
            tableView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            tableView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor)
        ])
        
        tableView.register(TableViewCell.self, forCellReuseIdentifier: CellReuseIdentifiers.animal.rawValue)
        
        tableView.tableFooterView = UIView()
        
        tableView.dataSource = self
        tableView.delegate = self
    }
}

extension ViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        animals.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell: TableViewCell = tableView.dequeueReusableCell(
            withIdentifier: CellReuseIdentifiers.animal.rawValue,
            for: indexPath
        ) as? TableViewCell else {
            fatalError()
        }
        
        // update data
        cell.update(text: animals[indexPath.row])
        
        return cell
    }
}

extension ViewController: UITableViewDelegate {
    
}
